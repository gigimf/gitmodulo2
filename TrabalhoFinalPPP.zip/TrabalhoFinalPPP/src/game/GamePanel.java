package game;

import freezemonster.FreezeMonster;
import java.awt.*;
import javax.swing.*;

public class GamePanel extends JPanel {
    private int seconds = 0;  // Track the seconds
    private Timer timer;
    FreezeMonster freezeMonster;

    public GamePanel() {
        freezeMonster = new FreezeMonster();
        setFocusable(true);
        addKeyListener(freezeMonster);
    }

    public void start() {
        Timer timer = new Timer(16, e -> {
            freezeMonster.update();
            repaint();
        });
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, getWidth(), getHeight());
        freezeMonster.draw(g);
    }
}

