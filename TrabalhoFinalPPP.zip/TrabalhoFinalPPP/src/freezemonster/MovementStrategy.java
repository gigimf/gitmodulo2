package freezemonster;

public interface MovementStrategy {
    void move(Monster monster);
    void move(Woody woody);
}
