package freezemonster;

public class DirectionalMovement implements MovementStrategy {
    @Override
    public void move(Monster monster) {
        monster.setX(monster.getX() + 1);
        monster.setY(monster.getY() + 1);
    }

    @Override
    public void move(Woody woody) {
        woody.setX(woody.getX() + 5);
        woody.setY(woody.getY() + 5);
    }
}
