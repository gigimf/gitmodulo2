package freezemonster;

import java.util.Random;

public class RandomMovement implements MovementStrategy {
    @Override
    public void move(Monster monster) {
        Random rand = new Random();
        int newX = monster.getX() + rand.nextInt(11) - 5;
        int newY = monster.getY() + rand.nextInt(11) - 5;
        monster.setX(newX);
        monster.setY(newY);
    }

    @Override
    public void move(Woody woody) {
        Random rand = new Random();
        int newX = woody.getX() + rand.nextInt(11) - 5;
        int newY = woody.getY() + rand.nextInt(11) - 5;
        woody.setX(newX);
        woody.setY(newY);
    }
}
