package freezemonster;

import java.awt.*;

public class Ray {
    private int x, y, dx, dy;
    private Image img;

    public Ray(int x, int y, int dx, int dy) {
        this.x = x;
        this.y = y;
        this.dx = dx * 10;
        this.dy = dy * 10;
        img = ImageLoader.load("ray.png", 30, 30);
    }

    public void move() {
        x += dx;
        y += dy;
    }

    public void draw(Graphics g) {
        g.drawImage(img, x, y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 30, 30);
    }

    public boolean isOffScreen() {
        return x < 0 || x > 800 || y < 0 || y > 600;
    }
}

