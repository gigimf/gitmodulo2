package freezemonster;

import java.util.Random;

public class MonsterFactory {
    private static Random rand = new Random();

    // Método de fábrica para criar monstros
    public static Monster createMonster() {
        Monster monster = new Monster();
        monster.setImage("monster" + (rand.nextInt(9) + 1) + ".png"); // Definindo a imagem aleatória
        return monster;
    }
}
