package freezemonster;

import java.awt.*;
import javax.swing.*;

public class Woody {
    private int x, y, dx, dy;
    private Image img;

    public Woody(int x, int y) {
        this.x = x;
        this.y = y;
        img = ImageLoader.getInstance().load("woody.png", 50, 50);
    }

    public void setDir(int dx, int dy) {
        this.dx = dx;
        this.dy = dy;
    }

    public void move() {
        int panelWidth = 800;
        int panelHeight = 600;

        if (x + dx * 5 >= 0 && x + dx * 5 <= panelWidth - 50) {
            x += dx * 5;
        }
        if (y + dy * 5 >= 0 && y + dy * 5 <= panelHeight - 50) {
            y += dy * 5;
        }
    }

    public void draw(Graphics g) {
        g.drawImage(img, x, y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 50, 50);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    // Métodos para acessar as coordenadas
    public int getX() { return x; }
    public int getY() { return y; }
    public int getDirX() { return dx; }
    public int getDirY() { return dy; }
}

