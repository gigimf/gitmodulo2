package freezemonster;

import java.awt.*;
import java.util.Random;

public class Gosma {
    private int x, y, dx, dy;
    private Image img;
    private static Random rand = new Random();

    public Gosma(int x, int y) {
        this.x = x;
        this.y = y;
        this.dx = rand.nextInt(11) - 5;
        this.dy = rand.nextInt(11) - 5;
        img = ImageLoader.load("gosma.png", 30, 30);
    }

    public void move() {
        x += dx;
        y += dy;
    }

    public void draw(Graphics g) {
        g.drawImage(img, x, y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 30, 30);
    }

    public boolean isOffScreen() {
        return x < 0 || x > 800 || y < 0 || y > 600;
    }
}

