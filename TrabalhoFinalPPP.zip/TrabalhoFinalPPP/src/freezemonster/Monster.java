package freezemonster;

import java.awt.*;
import java.util.Random;

public class Monster {
    private int x, y;
    private boolean frozen = false;
    private Image img;
    private Random rand;

    public Monster() {
        rand = new Random();
        this.x = rand.nextInt(700);
        this.y = rand.nextInt(500);
        this.img = ImageLoader.getInstance().load("monster" + (rand.nextInt(9) + 1) + ".png", 50, 50);
    }

    public void move() {
        int panelWidth = 800;
        int panelHeight = 600;

        if (!frozen) {
            int newX = x + rand.nextInt(11) - 5;
            int newY = y + rand.nextInt(11) - 5;

            if (newX >= 0 && newX <= panelWidth - 50) {
                x = newX;
            }
            if (newY >= 0 && newY <= panelHeight - 50) {
                y = newY;
            }
        }
    }

    public void draw(Graphics g) {
        g.drawImage(img, x, y, null);
    }

    public Rectangle getBounds() {
        return new Rectangle(x, y, 50, 50);
    }

    public void freeze() {
        frozen = true;
        img = ImageLoader.getInstance().load("monster" + (rand.nextInt(9) + 1) + "bg.png", 50, 50);
    }

    public boolean isFrozen() {
        return frozen;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    // Método para definir a imagem do monstro
    public void setImage(String image) {
        this.img = ImageLoader.getInstance().load(image, 50, 50);
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
}
