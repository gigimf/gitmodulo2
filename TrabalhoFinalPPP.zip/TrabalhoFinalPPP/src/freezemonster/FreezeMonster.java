package freezemonster;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class FreezeMonster extends JPanel implements KeyListener {
    private Woody woody;
    private java.util.List<Monster> monsters;
    private java.util.List<Ray> rays;
    private java.util.List<Gosma> gosmas;

    public FreezeMonster() {
        woody = new Woody(100, 100);
        monsters = new ArrayList<>();
        rays = new ArrayList<>();
        gosmas = new ArrayList<>();
        for (int i = 0; i < 5; i++) monsters.add(new Monster());
    }

    public void update() {
        woody.move();
        for (Ray ray : rays) ray.move();
        for (Gosma g : gosmas) g.move();
        for (Monster m : monsters) m.move();

        // Colisões
        Iterator<Ray> rayIter = rays.iterator();
        while (rayIter.hasNext()) {
            Ray ray = rayIter.next();
            for (Monster m : monsters) {
                if (!m.isFrozen() && ray.getBounds().intersects(m.getBounds())) {
                    m.freeze();
                    rayIter.remove();
                    break;
                }
            }
        }

        Iterator<Gosma> gIter = gosmas.iterator();
        while (gIter.hasNext()) {
            Gosma g = gIter.next();
            if (g.getBounds().intersects(woody.getBounds())) {
                JOptionPane.showMessageDialog(this, "Woody foi atingido! Fim de jogo.");
                System.exit(0);
            }
        }

        rays.removeIf(Ray::isOffScreen);
        gosmas.removeIf(Gosma::isOffScreen);

        // Vitória
        if (monsters.stream().allMatch(Monster::isFrozen)) {
            JOptionPane.showMessageDialog(this, "Todos os monstros foram congelados! Você venceu.");
            System.exit(0);
        }
    }

    public void draw(Graphics g) {
        woody.draw(g);
        for (Monster m : monsters) m.draw(g);
        for (Ray r : rays) r.draw(g);
        for (Gosma goo : gosmas) goo.draw(g);
    }

    public void keyPressed(KeyEvent e) {
        int code = e.getKeyCode();
        if (code == KeyEvent.VK_LEFT) woody.setDir(-1, 0);
        else if (code == KeyEvent.VK_RIGHT) woody.setDir(1, 0);
        else if (code == KeyEvent.VK_UP) woody.setDir(0, -1);
        else if (code == KeyEvent.VK_DOWN) woody.setDir(0, 1);
        else if (code == KeyEvent.VK_SPACE) rays.add(new Ray(woody.getX(), woody.getY(), woody.getDirX(), woody.getDirY()));
    }

    public void keyReleased(KeyEvent e) { }
    public void keyTyped(KeyEvent e) { }
}

