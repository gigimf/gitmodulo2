package freezemonster;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.net.URL;

public class ImageLoader {
    private static ImageLoader instance;

    // Construtor privado para evitar instâncias externas
    private ImageLoader() {}

    // Método para obter a instância da classe
    public static ImageLoader getInstance() {
        if (instance == null) {
            instance = new ImageLoader();
        }
        return instance;
    }

    public static Image load(String filename, int w, int h) {
        URL url = ImageLoader.class.getClassLoader().getResource("images/" + filename);
        if (url == null) {
            System.err.println("Imagem não encontrada: images/" + filename);
            return new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB); // imagem transparente padrão
        }
        ImageIcon icon = new ImageIcon(url);
        return icon.getImage().getScaledInstance(w, h, Image.SCALE_SMOOTH);
    }
}
