class Transporte {
    private Veiculo veiculo;
    private Motorista motorista;
    private String origem;
    private String destino;
    private boolean emAndamento;

    public Transporte(Veiculo veiculo, Motorista motorista, String destino) {
        if (!veiculo.isDisponivel() || !motorista.isDisponivel()) {
            throw new IllegalStateException("Veículo ou motorista indisponível para transporte");
        }

        this.veiculo = veiculo;
        this.motorista = motorista;
        this.origem = veiculo.getLocalizacaoAtual();
        this.destino = destino;
        this.emAndamento = true;

        // Atualize o status
        veiculo.setLocalizacaoAtual("Em trânsito para " + destino);
        motorista.setDisponivel(false);
    }

    public void concluirTransporte() {
        if (emAndamento) {
            veiculo.setLocalizacaoAtual(destino);
            motorista.setDisponivel(true);
            emAndamento = false;
        }
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public Motorista getMotorista() {
        return motorista;
    }

    public String getOrigem() {
        return origem;
    }

    public String getDestino() {
        return destino;
    }

    public boolean isEmAndamento() {
        return emAndamento;
    }
}