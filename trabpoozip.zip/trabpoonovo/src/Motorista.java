class Motorista {
    private String nome;
    private String cpf;
    private String categoriaHabilitacao;
    private boolean disponivel;

    public Motorista(String nome, String cpf, String categoriaHabilitacao) {
        this.nome = nome;
        this.cpf = cpf;
        this.categoriaHabilitacao = categoriaHabilitacao;
        this.disponivel = true;
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getCategoriaHabilitacao() {
        return categoriaHabilitacao;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }

    @Override
    public String toString() {
        return "Nome: " + nome +
                ", CPF: " + cpf +
                ", Categoria Habilitação: " + categoriaHabilitacao +
                ", Status: " + (disponivel ? "Disponível" : "Ocupado");
    }
}