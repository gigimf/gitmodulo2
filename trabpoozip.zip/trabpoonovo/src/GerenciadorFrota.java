import java.util.ArrayList;
import java.util.List;

class GerenciadorFrota {
    private List<Veiculo> veiculos;
    private List<Motorista> motoristas;
    private List<Transporte> transportesAtivos;

    public GerenciadorFrota() {
        this.veiculos = new ArrayList<>();
        this.motoristas = new ArrayList<>();
        this.transportesAtivos = new ArrayList<>();
    }

    public void cadastrarVeiculo(Veiculo veiculo) {
        veiculos.add(veiculo);
    }

    public void cadastrarMotorista(Motorista motorista) {
        motoristas.add(motorista);
    }

    public void iniciarManutencao(String placa) {
        Veiculo veiculo = buscarVeiculoPorPlaca(placa);
        if (veiculo != null) {
            veiculo.iniciarManutencao();
        } else {
            System.out.println("Veículo não encontrado.");
        }
    }

    public void finalizarManutencao(String placa) {
        Veiculo veiculo = buscarVeiculoPorPlaca(placa);
        if (veiculo != null) {
            veiculo.finalizarManutencao();
        } else {
            System.out.println("Veículo não encontrado.");
        }
    }

    public void iniciarTransporte(String placa, String cpfMotorista, String destino) {
        Veiculo veiculo = buscarVeiculoPorPlaca(placa);
        Motorista motorista = buscarMotoristaPorCpf(cpfMotorista);

        if (veiculo != null && motorista != null) {
            try {
                Transporte transporte = new Transporte(veiculo, motorista, destino);
                transportesAtivos.add(transporte);
                System.out.println("Transporte iniciado com sucesso!");
            } catch (IllegalStateException e) {
                System.out.println("Erro ao iniciar transporte: " + e.getMessage());
            }
        } else {
            System.out.println("Veículo ou motorista não encontrado.");
        }
    }

    public void concluirTransporte(String placa) {
        for (Transporte transporte : transportesAtivos) {
            if (transporte.getVeiculo().getPlaca().equals(placa) && transporte.isEmAndamento()) {
                transporte.concluirTransporte();
                transportesAtivos.remove(transporte);
                System.out.println("Transporte concluído com sucesso!");
                return;
            }
        }
        System.out.println("Transporte não encontrado ou já concluído.");
    }

    public void consultarLocalizacaoVeiculo(String placa) {
        Veiculo veiculo = buscarVeiculoPorPlaca(placa);
        if (veiculo != null) {
            System.out.println("Localização do veículo " + placa + ": " + veiculo.getLocalizacaoAtual());
        } else {
            System.out.println("Veículo não encontrado.");
        }
    }

    public void listarVeiculosPorCidade(String cidade) {
        System.out.println("Veículos em " + cidade + ":");
        boolean encontrou = false;

        for (Veiculo veiculo : veiculos) {
            if (veiculo.getLocalizacaoAtual().equals(cidade)) {
                System.out.println(veiculo);
                encontrou = true;
            }
        }

        if (!encontrou) {
            System.out.println("Nenhum veículo encontrado em " + cidade);
        }
    }

    public void listarTodosVeiculos() {
        System.out.println("Lista de todos os veículos:");
        for (Veiculo veiculo : veiculos) {
            System.out.println(veiculo);
        }
    }

    public void listarTodosMotoristas() {
        System.out.println("Lista de todos os motoristas:");
        for (Motorista motorista : motoristas) {
            System.out.println(motorista);
        }
    }

    private Veiculo buscarVeiculoPorPlaca(String placa) {
        for (Veiculo veiculo : veiculos) {
            if (veiculo.getPlaca().equals(placa)) {
                return veiculo;
            }
        }
        return null;
    }

    private Motorista buscarMotoristaPorCpf(String cpf) {
        for (Motorista motorista : motoristas) {
            if (motorista.getCpf().equals(cpf)) {
                return motorista;
            }
        }
        return null;
    }
}