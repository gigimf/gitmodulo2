class Caminhao extends Veiculo {
    private double capacidadeCarga;
    private int numeroEixos;

    public Caminhao(String placa, String modelo, String cor, double capacidadeCarga, int numeroEixos) {
        super(placa, modelo, cor);
        this.capacidadeCarga = capacidadeCarga;
        this.numeroEixos = numeroEixos;
    }

    public double getCapacidadeCarga() {
        return capacidadeCarga;
    }

    public int getNumeroEixos() {
        return numeroEixos;
    }

    @Override
    public String toString() {
        return "CAMINHÃO - " + super.toString() +
                ", Capacidade de Carga: " + capacidadeCarga + " toneladas" +
                ", Número de Eixos: " + numeroEixos;
    }
}