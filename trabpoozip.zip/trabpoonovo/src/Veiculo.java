
class Veiculo {
    private String placa;
    private String modelo;
    private String cor;
    private String localizacaoAtual;
    private boolean emManutencao;

    public Veiculo(String placa, String modelo, String cor) {
        this.placa = placa;
        this.modelo = modelo;
        this.cor = cor;
        this.localizacaoAtual = "Sede";
        this.emManutencao = false;
    }

    public String getPlaca() {
        return placa;
    }

    public String getModelo() {
        return modelo;
    }

    public String getCor() {
        return cor;
    }

    public String getLocalizacaoAtual() {
        return localizacaoAtual;
    }

    public void setLocalizacaoAtual(String localizacaoAtual) {
        this.localizacaoAtual = localizacaoAtual;
    }

    public boolean isEmManutencao() {
        return emManutencao;
    }

    public void iniciarManutencao() {
        this.emManutencao = true;
        this.localizacaoAtual = "Na Oficina";
    }

    public void finalizarManutencao() {
        this.emManutencao = false;
        this.localizacaoAtual = "Sede";
    }

    public boolean isDisponivel() {
        return !emManutencao;
    }

    @Override
    public String toString() {
        return "Placa: " + placa +
                ", Modelo: " + modelo +
                ", Cor: " + cor +
                ", Localização: " + localizacaoAtual +
                ", Status: " + (emManutencao ? "Em Manutenção" : "Disponível");
    }
}