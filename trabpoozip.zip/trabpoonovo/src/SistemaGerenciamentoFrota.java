// Alunos: Amanda Gomes - 122221bcc016 ; Giovana M. Ferreira - 12221bcc033; Pedro Ferreira 12421bsi2477import java.util.Scanner;

import java.util.Scanner;

public class SistemaGerenciamentoFrota {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GerenciadorFrota gerenciador = new GerenciadorFrota();

        // Pré-carregando alguns dados para teste
        preCarregarDados(gerenciador);

        int opcao;
        do {
            exibirMenu();
            opcao = Integer.parseInt(scanner.nextLine());

            switch (opcao) {
                case 1:
                    cadastrarVeiculo(scanner, gerenciador);
                    break;
                case 2:
                    cadastrarMotorista(scanner, gerenciador);
                    break;
                case 3:
                    registrarManutencao(scanner, gerenciador);
                    break;
                case 4:
                    finalizarManutencao(scanner, gerenciador);
                    break;
                case 5:
                    iniciarTransporte(scanner, gerenciador);
                    break;
                case 6:
                    concluirTransporte(scanner, gerenciador);
                    break;
                case 7:
                    consultarLocalizacao(scanner, gerenciador);
                    break;
                case 8:
                    listarVeiculosPorCidade(scanner, gerenciador);
                    break;
                case 9:
                    gerenciador.listarTodosVeiculos();
                    break;
                case 10:
                    gerenciador.listarTodosMotoristas();
                    break;
                case 0:
                    System.out.println("Encerrando o sistema...");
                    break;
                default:
                    System.out.println("Opção inválida!");
            }

            if (opcao != 0) {
                System.out.println("\nPressione ENTER para continuar...");
                scanner.nextLine();
            }

        } while (opcao != 0);

        scanner.close();
    }

    private static void exibirMenu() {
        System.out.println("\n=== SISTEMA DE GERENCIAMENTO DE FROTA ===");
        System.out.println("1. Cadastrar novo veículo");
        System.out.println("2. Cadastrar novo motorista");
        System.out.println("3. Registrar manutenção");
        System.out.println("4. Finalizar manutenção");
        System.out.println("5. Iniciar transporte");
        System.out.println("6. Concluir transporte");
        System.out.println("7. Consultar localização de veículo");
        System.out.println("8. Listar veículos por cidade");
        System.out.println("9. Listar todos os veículos");
        System.out.println("10. Listar todos os motoristas");
        System.out.println("0. Sair");
        System.out.print("Escolha uma opção: ");
    }

    private static void cadastrarVeiculo(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== CADASTRO DE VEÍCULO ===");
        System.out.println("Tipo de veículo:");
        System.out.println("1. Carro");
        System.out.println("2. Caminhão");
        System.out.println("3. Moto");
        System.out.print("Escolha o tipo: ");
        int tipo = Integer.parseInt(scanner.nextLine());

        System.out.print("Placa: ");
        String placa = scanner.nextLine();

        System.out.print("Modelo: ");
        String modelo = scanner.nextLine();

        System.out.print("Cor: ");
        String cor = scanner.nextLine();

        switch (tipo) {
            case 1:
                System.out.print("Número de portas: ");
                int portas = Integer.parseInt(scanner.nextLine());

                System.out.print("Tipo de combustível: ");
                String combustivel = scanner.nextLine();

                gerenciador.cadastrarVeiculo(new Carro(placa, modelo, cor, portas, combustivel));
                break;

            case 2:
                System.out.print("Capacidade de carga (toneladas): ");
                double capacidade = Double.parseDouble(scanner.nextLine());

                System.out.print("Número de eixos: ");
                int eixos = Integer.parseInt(scanner.nextLine());

                gerenciador.cadastrarVeiculo(new Caminhao(placa, modelo, cor, capacidade, eixos));
                break;

            case 3:
                System.out.print("Cilindradas: ");
                int cilindradas = Integer.parseInt(scanner.nextLine());

                gerenciador.cadastrarVeiculo(new Moto(placa, modelo, cor, cilindradas));
                break;

            default:
                System.out.println("Tipo de veículo inválido!");
                return;
        }

        System.out.println("Veículo cadastrado com sucesso!");
    }

    private static void cadastrarMotorista(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== CADASTRO DE MOTORISTA ===");

        System.out.print("Nome: ");
        String nome = scanner.nextLine();

        System.out.print("CPF: ");
        String cpf = scanner.nextLine();

        System.out.print("Categoria da habilitação (A, B, C, D, E): ");
        String categoria = scanner.nextLine().toUpperCase();

        gerenciador.cadastrarMotorista(new Motorista(nome, cpf, categoria));
        System.out.println("Motorista cadastrado com sucesso!");
    }

    private static void registrarManutencao(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== REGISTRAR MANUTENÇÃO ===");

        System.out.print("Placa do veículo: ");
        String placa = scanner.nextLine();

        gerenciador.iniciarManutencao(placa);
    }

    private static void finalizarManutencao(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== FINALIZAR MANUTENÇÃO ===");

        System.out.print("Placa do veículo: ");
        String placa = scanner.nextLine();

        gerenciador.finalizarManutencao(placa);
    }

    private static void iniciarTransporte(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== INICIAR TRANSPORTE ===");

        System.out.print("Placa do veículo: ");
        String placa = scanner.nextLine();

        System.out.print("CPF do motorista: ");
        String cpf = scanner.nextLine();

        System.out.print("Cidade de destino: ");
        String destino = scanner.nextLine();

        gerenciador.iniciarTransporte(placa, cpf, destino);
    }

    private static void concluirTransporte(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== CONCLUIR TRANSPORTE ===");

        System.out.print("Placa do veículo: ");
        String placa = scanner.nextLine();

        gerenciador.concluirTransporte(placa);
    }

    private static void consultarLocalizacao(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== CONSULTAR LOCALIZAÇÃO ===");

        System.out.print("Placa do veículo: ");
        String placa = scanner.nextLine();

        gerenciador.consultarLocalizacaoVeiculo(placa);
    }

    private static void listarVeiculosPorCidade(Scanner scanner, GerenciadorFrota gerenciador) {
        System.out.println("\n=== LISTAR VEÍCULOS POR CIDADE ===");

        System.out.print("Nome da cidade: ");
        String cidade = scanner.nextLine();

        gerenciador.listarVeiculosPorCidade(cidade);
    }

    private static void preCarregarDados(GerenciadorFrota gerenciador) {
        // Veículos
        gerenciador.cadastrarVeiculo(new Carro("ABC1234", "Toyota Corolla", "Preto", 4, "Flex"));
        gerenciador.cadastrarVeiculo(new Carro("DEF5678", "Honda Civic", "Branco", 4, "Gasolina"));
        gerenciador.cadastrarVeiculo(new Caminhao("GHI9012", "Volvo FH", "Vermelho", 15.5, 5));
        gerenciador.cadastrarVeiculo(new Moto("JKL3456", "Honda CG 150", "Azul", 150));

        // Motoristas
        gerenciador.cadastrarMotorista(new Motorista("João Silva", "123.456.789-00", "B"));
        gerenciador.cadastrarMotorista(new Motorista("Maria Oliveira", "987.654.321-00", "A"));
        gerenciador.cadastrarMotorista(new Motorista("Carlos Pereira", "111.222.333-44", "E"));

        // Inicializando alguns veículos em cidades diferentes para testes
        gerenciador.iniciarTransporte("DEF5678", "123.456.789-00", "São Paulo");
        gerenciador.concluirTransporte("DEF5678");

        gerenciador.iniciarTransporte("JKL3456", "987.654.321-00", "Rio de Janeiro");
        gerenciador.concluirTransporte("JKL3456");
    }
}