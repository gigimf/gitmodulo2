class Carro extends Veiculo {
    private int numeroPortas;
    private String tipoCombustivel;

    public Carro(String placa, String modelo, String cor, int numeroPortas, String tipoCombustivel) {
        super(placa, modelo, cor);
        this.numeroPortas = numeroPortas;
        this.tipoCombustivel = tipoCombustivel;
    }

    public int getNumeroPortas() {
        return numeroPortas;
    }

    public String getTipoCombustivel() {
        return tipoCombustivel;
    }

    @Override
    public String toString() {
        return "CARRO - " + super.toString() +
                ", Número de Portas: " + numeroPortas +
                ", Combustível: " + tipoCombustivel;
    }
}